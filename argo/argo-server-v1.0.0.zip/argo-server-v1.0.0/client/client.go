package main

import (
	"argo-server/consts"
	"fmt"
	"os"
	"os/signal"
	"syscall"
	"time"

	"argo-server/client/c_router"

	"github.com/aceld/zinx/ziface"
	"github.com/aceld/zinx/zlog"
	"github.com/aceld/zinx/znet"
)

// 客户端自定义业务
func business(conn ziface.IConnection) {

	count := 0

	for {
		count++
		err := conn.SendMsg(consts.MESSAGE_C2S_PING, []byte("Ping...[FromClient]"))
		if err != nil {
			fmt.Println(err)
			zlog.Error(err)
			break
		}

		time.Sleep(5 * time.Second)
		if count >= 1 {
			break
		}
	}
}

// 创建连接的时候执行
func DoClientConnectedBegin(conn ziface.IConnection) {
	zlog.Debug("DoConnecionBegin is Called ... ")

	//设置两个链接属性，在连接创建之后
	conn.SetProperty("Name", "DTUClient001")

	go business(conn)
}

// 连接断开的时候执行
func DoClientConnectedLost(conn ziface.IConnection) {
	//在连接销毁之前，查询conn的Name，Home属性
	if name, err := conn.GetProperty("Name"); err == nil {
		zlog.Debug("Conn Property Name = ", name)
	}

	zlog.Debug("DoClientConnectedLost is Called ... ")
}

func main() {
	//创建一个Client句柄，使用Zinx的API
	client := znet.NewClient("127.0.0.1", 8999)

	//添加首次建立链接时的业务
	client.SetOnConnStart(DoClientConnectedBegin)
	client.SetOnConnStop(DoClientConnectedLost)

	//注册收到服务器消息业务路由
	client.AddRouter(consts.MESSAGE_S2C_PING, &c_router.PingRouter{})
	client.AddRouter(consts.MESSAGE_S2C_UPLOAD, &c_router.UploadRouter{})

	//启动客户端client
	client.Start()

	// close
	c := make(chan os.Signal, 1)
	signal.Notify(c, os.Interrupt, syscall.SIGHUP, syscall.SIGQUIT, syscall.SIGTERM, syscall.SIGINT)
	sig := <-c
	fmt.Println("===exit===", sig)
	// 清理客户端
	client.Stop()
	time.Sleep(time.Second * 2)
}
