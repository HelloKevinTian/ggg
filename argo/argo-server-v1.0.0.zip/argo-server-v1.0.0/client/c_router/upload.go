package c_router

import (
	"fmt"

	"github.com/aceld/zinx/ziface"
	"github.com/aceld/zinx/zlog"
	"github.com/aceld/zinx/znet"
)

type UploadRouter struct {
	znet.BaseRouter
}

//Ping Handle
func (ur *UploadRouter) Handle(request ziface.IRequest) {
	fmt.Println("Upload Done.")
	zlog.Debug("Upload Done.")

	zlog.Debug("recv from server : msgId=", request.GetMsgID(), ", data=", string(request.GetData()))
	fmt.Println("recv from server : msgId=", request.GetMsgID(), ", data=", string(request.GetData()))
}
