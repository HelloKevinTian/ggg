package c_router

import (
	"argo-server/consts"
	"encoding/json"
	"fmt"

	"github.com/aceld/zinx/ziface"
	"github.com/aceld/zinx/zlog"
	"github.com/aceld/zinx/znet"
)

//ping test 自定义路由
type PingRouter struct {
	znet.BaseRouter
}

//Ping Handle
func (pr *PingRouter) Handle(request ziface.IRequest) {
	fmt.Println("Call PingRouter Handle")
	zlog.Debug("Call PingRouter Handle")
	//先读取客户端的数据，再回写ping...ping...ping
	zlog.Debug("recv from server : msgId=", request.GetMsgID(), ", data=", string(request.GetData()))
	fmt.Println("recv from server : msgId=", request.GetMsgID(), ", data=", string(request.GetData()))

	uploadData := map[string]interface{}{
		"DTUSN": "025006220830000061470",
		"Func":  "UpLinkMessage",
		"Message": map[string]interface{}{
			"sReelUp":               false, //Message对象内包含的所有键值都是需要存入 数据库对应DTUSN的表单中
			"sHeaderDown":           false, //值类型有共有三种：string\int\float
			"sHeaderUp":             false,
			"mMainClutchStateClose": false,
			"mMainClutchStateOpen":  false,
			"sRotorDown":            false,
			"sRotorUp":              false,
			"mReelDown":             false,
			"mHeaderDown":           false,
			"mHeaderUp":             false,
			"mRotorDown":            true,
		},
	}

	uploadBytes, err := json.Marshal(uploadData)
	if err != nil {
		zlog.Error(err)
	}

	if err := request.GetConnection().SendBuffMsg(consts.MESSAGE_C2S_UPLOAD, uploadBytes); err != nil {
		zlog.Error(err)
	}
}
