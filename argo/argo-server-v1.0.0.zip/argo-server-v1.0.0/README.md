## argo-server

### 支持的功能列表
> 实现TCP服务端，支持Socket长连接
> 支持自定义协议通信，支持JSON数据解析
> 支持客户端连接认证
> 支持数据库存储
> 客户端连接管理，数据多端转发，广播转发

### 服务器项目文档
https://www.yuque.com/aceld/tsgooa/sbvzgczh3hqz8q3l