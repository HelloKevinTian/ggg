package dao

import (
	"fmt"
	"log"
	"os"
	"time"

	"github.com/aceld/zinx/zlog"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
)

var EnvName string

var mdb *gorm.DB

var (
	username = "dba"
	password = "123456"
	host     = "43.138.84.72"
	port     = "3306"
	dbname   = "ltedtu"
)

func getLogger() logger.Interface {
	return logger.New(log.New(os.Stdout, "\r\n", log.LstdFlags), // io writer
		logger.Config{
			SlowThreshold: time.Second,   // 慢 SQL 阈值
			LogLevel:      logger.Silent, // Log level
			Colorful:      true,          // 禁用彩色打印
		})
}

func MustConnectMysqlGorm() {
	dsn := fmt.Sprintf("%s:%s@tcp(%s:%s)/%s?charset=utf8&parseTime=True&loc=Local",
		username,
		password,
		host,
		port,
		dbname)
	ormConfig := gorm.Config{Logger: logger.Default.LogMode(logger.Info)}
	if EnvName == "prod" {
		ormConfig = gorm.Config{Logger: getLogger()}
	}
	db, err := gorm.Open(mysql.Open(dsn), &ormConfig)
	if err := setConnectionPool(db); err != nil {
		panic(err)
	}
	if err != nil {
		panic(err)
	}
	mdb = db
	zlog.Ins().InfoF("Mysql Init success.")
}

func setConnectionPool(db *gorm.DB) error {
	sqlDB, err := db.DB()
	if err != nil {
		return fmt.Errorf("get connection pool error : %v", err)
	}

	sqlDB.SetMaxIdleConns(5)
	sqlDB.SetMaxOpenConns(100)
	sqlDB.SetConnMaxLifetime(30 * time.Minute)
	return nil
}
