package dao

var TableDevices = "devices"

type Devices struct {
	Dtusn      string `gorm:"primaryKey;autoIncrement:false"`
	Dtumaker   string
	Dtumodel   string
	Userid     int
	Status     int
	Dtuonline  int
	Terminalid int
	Createtime int64
	Njtitle    string
	Njcode     string
	Njtype     string
	Njmaker    string
	Njmodel    string
}
