package dao

import (
	"time"

	"github.com/aceld/zinx/zlog"
)

var TableMessages = "messages"

type Messages struct {
	Messageid  int `gorm:"primaryKey;not null;autoIncrement"`
	Dtusn      string
	Func       string
	Message    string
	Createtime time.Time
}

func SaveMessage(msg *Messages) {
	if err := mdb.Table(TableMessages).Create(msg).Error; err != nil {
		zlog.Ins().ErrorF("SaveMessage error: %s", err.Error())
		panic(err)
	}
}

func GetMessageByID(id int) *Messages {
	var item *Messages
	if err := mdb.Table(TableMessages).
		Select("messageid", "dtusn", "func", "message", "createtime").
		Where("messageid IN ?", []int{id}).
		Find(&item).Error; err != nil {
		zlog.Ins().ErrorF("GetAllFromTableDecodeJson: %s", err.Error())
	}
	return item
}
