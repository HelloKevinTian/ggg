package dao

import (
	"github.com/aceld/zinx/zlog"
)

var TableDecodeJson = "decodejson"

type DecodeJson struct {
	ID         int `gorm:"primaryKey"`
	Dtusn      string
	Decodeid   string
	Decodedata string
}

func GetAllFromTableDecodeJson() {
	var dj []DecodeJson
	if err := mdb.Table(TableDecodeJson).
		Select("id", "dtusn", "decodeid", "decodedata").
		Where("id IN ?", []int{1, 287}).
		Find(&dj).Error; err != nil {
		zlog.Ins().ErrorF("GetAllFromTableDecodeJson: %s", err.Error())
	}

	zlog.Ins().DebugF("GetAllFromTableDecodeJson: %v", dj)
}
