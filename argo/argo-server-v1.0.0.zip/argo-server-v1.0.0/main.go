package main

import (
	"argo-server/consts"
	"argo-server/dao"
	"argo-server/routers"

	"github.com/aceld/zinx/ziface"
	"github.com/aceld/zinx/zlog"
	"github.com/aceld/zinx/znet"
)

// PingRouter MsgId=1
type PingRouter struct {
	znet.BaseRouter
}

// 创建连接的时候执行
func DoConnectionBegin(conn ziface.IConnection) {
	zlog.Ins().InfoF("DoConnecionBegin is Called ...")

	//设置两个链接属性，在连接创建之后
	conn.SetProperty("Name", "DTUClient")

	// err := conn.SendMsg(2, []byte("DoConnection BEGIN..."))
	// if err != nil {
	// 	zlog.Error(err)
	// }
}

// 连接断开的时候执行
func DoConnectionLost(conn ziface.IConnection) {
	//在连接销毁之前，查询conn的Name，Home属性
	if name, err := conn.GetProperty("Name"); err == nil {
		zlog.Ins().InfoF("Conn Property Name = %v", name)
	}

	zlog.Ins().InfoF("Conn is Lost")
}

func doInit() {
	dao.MustConnectMysqlGorm()
}

func main() {
	// 创建一个server句柄
	s := znet.NewServer()

	// 注册链接hook回调函数
	s.SetOnConnStart(DoConnectionBegin)
	s.SetOnConnStop(DoConnectionLost)

	// 配置路由
	s.AddRouter(consts.MESSAGE_C2S_PING, &routers.PingRouter{})
	s.AddRouter(consts.MESSAGE_C2S_UPLOAD, &routers.UploadRouter{})
	s.AddRouter(consts.MESSAGE_C2S_UPLOAD_NO_REPLY, &routers.UploadNoReplyRouter{})

	doInit()

	// 开启服务
	s.Serve()
}
