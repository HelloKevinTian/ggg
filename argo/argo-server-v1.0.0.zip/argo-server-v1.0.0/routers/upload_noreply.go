package routers

import (
	"argo-server/dao"
	"fmt"

	"github.com/aceld/zinx/ziface"
	"github.com/aceld/zinx/zlog"
	"github.com/aceld/zinx/znet"
)

type UploadNoReplyRouter struct {
	znet.BaseRouter
}

//Ping Handle
func (ur *UploadNoReplyRouter) Handle(request ziface.IRequest) {

	zlog.Ins().DebugF("Call UploadNoReplyRouter Handle")
	zlog.Ins().DebugF("recv from client : msgId=%d, data=%+v, len=%d", request.GetMsgID(), string(request.GetData()), len(request.GetData()))

	dmsg := ParseMessage(request.GetData())
	if dmsg != nil { //save
		fmt.Println("save dmsg===> ", dmsg)
		dao.SaveMessage(dmsg)
	}
}
