package routers

import (
	"encoding/json"
)

type Response struct {
	Code    int32  `json:"code"`
	Message string `json:"message,omitempty"`
	Data    string `json:"data,omitempty"`
}

func MsgSucc(data string) []byte {
	r := Response{}
	r.Code = 0
	r.Data = data
	v, _ := json.Marshal(r)
	return v
}
