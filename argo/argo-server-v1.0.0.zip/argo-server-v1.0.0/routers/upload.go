package routers

import (
	"argo-server/consts"
	"argo-server/dao"
	"encoding/json"
	"fmt"
	"runtime/debug"
	"time"

	"github.com/aceld/zinx/ziface"
	"github.com/aceld/zinx/zlog"
	"github.com/aceld/zinx/znet"
)

type UploadRouter struct {
	znet.BaseRouter
}

//Ping Handle
func (ur *UploadRouter) Handle(request ziface.IRequest) {

	zlog.Ins().DebugF("Call UploadRouter Handle")
	zlog.Ins().DebugF("recv from client : msgId=%d, data=%+v, len=%d", request.GetMsgID(), string(request.GetData()), len(request.GetData()))

	dmsg := ParseMessage(request.GetData())
	if dmsg != nil { //save
		fmt.Println("save dmsg===> ", dmsg)
		dao.SaveMessage(dmsg)
	}

	err := request.GetConnection().SendMsg(consts.MESSAGE_S2C_UPLOAD, MsgSucc("ok"))
	if err != nil {
		zlog.Error(err)
	}
}

func ParseMessage(reqData []byte) (msg *dao.Messages) {
	defer func() {
		if r := recover(); r != nil {
			zlog.Error("ParseMessage Recovered: ", r, string(debug.Stack()))
			fmt.Println("ParseMessage Recovered: ", r, string(debug.Stack()))
			msg = nil
			return
		}
	}()
	reqmsg := make(map[string]interface{})
	if err := json.Unmarshal(reqData, &reqmsg); err != nil {
		zlog.Errorf("ParseMessage error: %s", err.Error())
	}
	fname, ok := reqmsg["Func"]
	if !ok {
		panic("no Func => " + string(reqData))
	}
	if fname.(string) != "UpLinkMessage" {
		panic("not UpLinkMessage => " + string(reqData))
	}

	msg = &dao.Messages{}
	msg.Func = fname.(string)
	if v, ok := reqmsg["DTUSN"]; ok {
		msg.Dtusn = v.(string)
	}
	if v, ok := reqmsg["Message"]; ok {
		b, _ := json.Marshal(v)
		msg.Message = string(b)
	}
	msg.Createtime = time.Now()
	return
}
