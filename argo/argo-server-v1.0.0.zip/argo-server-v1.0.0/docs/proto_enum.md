## 通信协议ID说明

| 协议ID   | 协议类型 | 协议说明 | 请求结构 |
|----- | ----- | ----- |  ----- |
| 100 | c2s | ping 发送消息  |  "ping" |
| 101 | s2c | ping 返回消息  |  "pong" |
| 102 | c2s | DTU upload消息  |  {} |
| 103 | s2c | DTU upload返回信息  |  "ok" |
| 104 | c2s | DTU upload消息，无返回信息  |  {} |

## 协议100 101说明

- DTU请求内容

```json
massage_id: 100
```

- DTU服务器返回内容

```json
massage_id: 101
{
    "code": 0,
    "data": "pong"
}
```

## 协议102 103说明

- DTU请求内容

```json
massage_id: 102
{
    "DTUSN": "02500622083000006147", //DTUSN,唯一标识符
    "Func": "UpLinkMessage",         //功能码，UpLinkMessage标识数据是上行方向（DTU->服务器）
    "Message": {
        "sReelUp": false,            //Message对象内包含的所有键值都是需要存入 数据库对应DTUSN的表单中
        "sHeaderDown": false,        //值类型有共有三种：string\int\float
        "sHeaderUp": false,
        "mMainClutchStateClose": false,
        "mMainClutchStateOpen": false,
        "sRotorDown": false,
        "sRotorUp": false,
        "mReelDown": false,
        "mHeaderDown": false,
        "mHeaderUp": false,
        "mRotorDown": true
    }
}
```

- DTU服务器返回内容

```json
massage_id: 103
{
    "code": 0,
    "data": "ok"
}
```