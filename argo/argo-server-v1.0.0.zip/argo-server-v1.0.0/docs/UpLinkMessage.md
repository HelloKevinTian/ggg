// DTU发送JSON报文格式说明
// 1.本文档定义了DTU向服务器发送的报文格式
// 2.DTUSN是唯一标识符。Func是功能码，用于记录数据流向。Message对象内的键值对为需存入数据库的数据。 

// 说明：
// a.不同信息的发送频率不同，如：报文1的发送频率为1HZ，报文2的发送频率为10Hz,报文3的发送频率为5Hz
//示例：报文1
```json
{
    "DTUSN": "02500622083000006147", //DTUSN,唯一标识符
    "Func": "UpLinkMessage",         //功能码，UpLinkMessage标识数据是上行方向（DTU->服务器）
    "Message": {
        "sReelUp": false,            //Message对象内包含的所有键值都是需要存入 数据库对应DTUSN的表单中
        "sHeaderDown": false,        //值类型有共有三种：string\int\float
        "sHeaderUp": false,
        "mMainClutchStateClose": false,
        "mMainClutchStateOpen": false,
        "sRotorDown": false,
        "sRotorUp": false,
        "mReelDown": false,
        "mHeaderDown": false,
        "mHeaderUp": false,
        "mRotorDown": true
    }
}
//示例：报文2
{
    "DTUSN": "02500622083000006147",
    "Func": "UpLinkMessage",
    "Message": {
        "mTemperatureNode1": 4621.0,
        "mPressureNode2": 10128.0,
        "mPressureNode1": 4653.0,
        "mGroundSpeed": 0
    }
}
//示例：报文3
{
    "DTUSN": "02500622083000006147",
    "Func": "UpLinkMessage",
    "Message": {
        "mAcceleratorPedalState": 0.0,
        "mRotorSpeed1": 0.0,
        "mTailElevatorSpeed1": 0.0,
        "mDuplicating1": 0.0,
        "mFanSpeed": 0.0,
        "mRotorSpeed2": 0.0,
        "mDuplicating2": 0.0,
        "mTailElevatorSpeed2": 0.0,
        "mSlasherSpeed": 0.0
    }
}
```