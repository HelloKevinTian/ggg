## messages表结构

```json
{
    "messageid": 2203,
    "dtusn": "02500622083000006147",
    "func": "UpLinkMessage",
    "data": "{\"mEngineSpeed\":8191.875,\"mEnginePower\":32767.5,\"mInstFuelConsumption\":131.07000732421875,\"mEngineOilPressure\":3276.75}",
    "createtime": "2023-02-18 21:21:41 +0800 CST"
}
```